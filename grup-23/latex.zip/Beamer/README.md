## Beamer 
Beamer is a powerful and flexible LaTeX class to create great looking presentations.

to compile 

```
pdflatex main.tex
```

for hidden note with each frame  

uncomment  ```\setbeameroption{show notes on second screen=right} ``` 

``` 
\note[item]{same text}
```
Not that you need two screens to make this work.. [read more](https://gist.github.com/andrejbauer/ac361549ac2186be0cdb) 

Also, you need to downlaod this python package [Pympress](https://github.com/Cimbali/pympress)


